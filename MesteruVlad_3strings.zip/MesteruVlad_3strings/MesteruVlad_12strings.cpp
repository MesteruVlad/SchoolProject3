#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
using namespace std;

int main()
{   char a[50]; int i;
    char b[50];
    cout<<"Scrieti primul text= ";
    gets(a);
    cout<<"Scrieti al doilea text= ";
    gets(b);
    int av[10]={0,0,0,0,0};
    int bv[10]={0,0,0,0,0};
    for(int i=0;i<strlen(a);i++)
        switch(a[i])
        {
            case 'a':{av[0]++;break;}
            case 'e':{av[1]++;break;}
            case 'i':{av[2]++;break;}
            case 'o':{av[3]++;break;}
            case 'u':{av[4]++;break;}
        }
    for(int i=0;i<strlen(b);i++)
        switch(b[i])
        {
            case 'a':{bv[0]++;break;}
            case 'e':{bv[1]++;break;}
            case 'i':{bv[2]++;break;}
            case 'o':{bv[3]++;break;}
            case 'u':{bv[4]++;break;}
        }
    int cv[10],x;
    for(int i=0;i<5;i++)
        {
            if(av[i]!=0 && bv[i]!=0)
                cv[i]=av[i]+bv[i];
            else cv[i]=0;
        }
    int minv;
    for(int i=0;i<5;i++)
    {
        if(cv[i]!=0)
        {
            minv=cv[i];
            break;
        }
    }

    for(int i=0;i<5;i++)
    {
        if(minv>cv[i] && cv[i]!=0)
        {
            minv=cv[i];
            x=i;
        }
    }
    switch(x)
    {
        case 0:{cout<<"a";break;}
        case 1:{cout<<"e";break;}
        case 2:{cout<<"i";break;}
        case 3:{cout<<"o";break;}
        case 4:{cout<<"u";break;}
    }
}
